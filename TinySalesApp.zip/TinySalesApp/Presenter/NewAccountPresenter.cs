﻿using System;
using System.Collections.Generic;
using System.Windows.Input;

namespace TinySalesApp
{
    class SaveCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;
        public bool CanExecute(object parameter)
        {
            return false;
        }

        public void Execute(object parameter)
        {   

        }
    }

    public interface INewAccountPresenter
    {
        int Number { get; set; }
        string Name { get; set; }
        byte Type { get; set; }
        ICommand SaveCommand { get; }
        List<AccountType> GetTypeList();
    }

    public class AccountType
    {
        public AccountType(string typeName, byte typeValue)
        {
            this.typeName = typeName;
            this.typeValue = typeValue;
        }
        public string typeName { get; }
        public byte typeValue { get; }
        public static List<AccountType> GetTypeList()
        {
            return new List<AccountType>()
           {
               new AccountType("ميزانية عمومية",1)
               ,
               new AccountType("ارباح وخسائر",2)
           };
        }
    }

    public class NewAccountPresenter : INewAccountPresenter
    {
        private ICommand saveCommand;
        private int accNumber;
        private string accName;
        private byte accType;
        /********************/
        public NewAccountPresenter()
        {
            this.accName = "";
            this.saveCommand = new SaveCommand();
        }
        //TinySalesApp.Presenter.NewAccountPresenter
        public ICommand SaveCommand { get => saveCommand; set => saveCommand = value; }
        public int Number { get => accNumber; set => accNumber = value; }
        public string Name { get => accName; set => accName = value; }
        public byte Type { get => accType; set => accType = value; }
        public List<AccountType> GetTypeList()
        {
            return AccountType.GetTypeList();
        }

    }
}
